package in.xenonstudio.anews;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;

public class SettingsActivity extends AppCompatActivity {

    CardView cdabout,cdnoti,cdper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        final int versionCode = BuildConfig.VERSION_CODE;
        final String versionName = BuildConfig.VERSION_NAME;

        cdabout = (CardView)findViewById(R.id.cd_about);
        cdnoti = (CardView)findViewById(R.id.cd_noti);


        cdnoti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction("android.settings.APP_NOTIFICATION_SETTINGS");

//for Android 5-7
                intent.putExtra("app_package", getPackageName());
                intent.putExtra("app_uid", getApplicationInfo().uid);

// for Android O
                intent.putExtra("android.provider.extra.APP_PACKAGE", getPackageName());

                startActivity(intent);
            }
        });

        cdabout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(SettingsActivity.this);

                builder.setMessage("\n App Is Developed By Xenon Studio, App Was Launched In Nov 2, 2017 \n We Are Making Our Apps More Users Friendly And Adding More Features \n");

                builder.setPositiveButton("GOT IT", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        dialogInterface.dismiss();
                    }
                }).setNegativeButton("Developer Contact", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        Intent send = new Intent(Intent.ACTION_SENDTO);
                        String uriText = "mailto:" + Uri.encode("thexenonstudio@gmail.com") +
                                "?subject=" + Uri.encode("Around Me - Developer Contact") +
                                "&body=" + Uri.encode("Hello, Type Your Query/Problem/Bug/Suggestions Here"+" \n\n\n ------------ \n\n Version Code : "+versionCode+"\n Version Name : "+versionName);
                        Uri uri = Uri.parse(uriText);

                        send.setData(uri);
                        startActivity(Intent.createChooser(send, "Send Mail Via : "));
                    }
                });

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        cdper = (CardView)findViewById(R.id.cd_per);
        cdper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.fromParts("package", getPackageName(), null);
                intent.setData(uri);
                startActivity(intent);
            }
        });
    }
}
