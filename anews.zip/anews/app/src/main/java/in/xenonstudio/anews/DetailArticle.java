package in.xenonstudio.anews;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ShareCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;

import dmax.dialog.SpotsDialog;

public class DetailArticle extends AppCompatActivity {

    WebView webView;
    SpotsDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_article);

        dialog = new SpotsDialog(this);
        dialog.show();
        //WebView
        webView = (WebView)findViewById(R.id.webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient(){

            //press Ctrl+O

            @Override
            public void onPageFinished(WebView view, String url) {
                dialog.dismiss();
            }
        });

        if(getIntent() != null)
        {
            if(!getIntent().getStringExtra("webURL").isEmpty())
                webView.loadUrl(getIntent().getStringExtra("webURL"));

           // Toast.makeText(this, ""+webView.getUrl(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_article, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.contact) {


            Toast toast = Toast.makeText(this, "Mail Us For More Detail", Toast.LENGTH_LONG);
            View view = toast.getView();

            view.getBackground().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN);

            TextView text = view.findViewById(android.R.id.message);
            text.setTextColor(Color.BLACK);

            toast.show();

            Intent send = new Intent(Intent.ACTION_SENDTO);
            String uriText = "mailto:" + Uri.encode("thexenonstudio@gmail.com") +
                    "?subject=" + Uri.encode("Globeat - Contact") +
                    "&body=" + Uri.encode("Hello, Type Your Query/Problem/Bug/Suggestions Here");
            Uri uri = Uri.parse(uriText);

            send.setData(uri);
            startActivity(Intent.createChooser(send, "Send Mail Via : "));

        }



       /* if (id == R.id.action_flash) {


            Toast.makeText(this, "Something Went Wrong ! ", Toast.LENGTH_SHORT).show();

            return true;
        }*/
        if (id == R.id.share) {


            ShareCompat.IntentBuilder.from(DetailArticle.this)
                    .setType("text/plain")
                    .setChooserTitle("Share URL")
                    .setText(""+webView.getTitle()+"\n"+webView.getUrl())
                    .startChooser();



            return true;
        }
        if (id == R.id.action_privacy) {

            Intent intent = getIntent();
            String URL = intent.getExtras().getString("URL");

            /*WebView webView = new WebView(QRUrlActivity.this);
            webView.loadUrl(URL);*/

            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse(webView.getOriginalUrl()));
            startActivity(i);


            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
